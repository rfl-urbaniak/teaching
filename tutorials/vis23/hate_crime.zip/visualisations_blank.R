library(ggplot2)
library(ggthemes)
library(tidyverse)
library(dplyr)



hc <- read.csv("hate_crime.csv", header = TRUE)


names(hc)
nrow(hc)

str(hc$STATE_ABBR)

hc$STATE_ABBR <- as.factor(hc$STATE_ABBR)

levels(hc$STATE_ABBR)


hcState <- hc %>% group_by(STATE_ABBR) %>% 
  summarise(OCCURRENCES = n()) 

arrange(hcState, desc(OCCURRENCES))

hcState <- arrange(hcState, desc(OCCURRENCES))


ggplot(hcState)+geom_col(
                  aes(x = STATE_ABBR, y = OCCURRENCES)
                            )


ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, desc(OCCURRENCES)),
                  y = OCCURRENCES)
)


ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() 


ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_fivethirtyeight(base_size = 8)


ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_fivethirtyeight(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")


ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_fivethirtyeight(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot")

ggplot(hcState)+geom_col(
  aes(x = reorder(STATE_ABBR, OCCURRENCES),
      y = OCCURRENCES)
) + coord_flip() +
  theme_gdocs(base_size = 8)+
  labs(title = "Hate crimes in USA by state",
       subtitle = "1991-2017")+
  theme(plot.title.position = "plot")+
  ylab("total number of hate crimes")+
  xlab("")



#check out https://yutannihilation.github.io/allYourFigureAreBelongToUs/ggthemes/

#____________________________
#NOW YOUR TURN
#____________________________



#E1 
#A. group by year and summarize by counts
hcYear <- hc %>% group_by(_____) %>% summarise(_____ = n())

#B. Check names and no of rows
names(_____)
nrow(_____)

#C. Rename the columns to "year" and "crimes"
names(hcYear) <- c(_____, _____)

#D. Prepare and inspect a basic plot of crimes vs years
hcYearPlot <- ggplot(hcYear, aes(x = _____, _____))+
  geom_line()

hcYearPlot

#E. add highcharts JS theme by adding theme_hc() and a meaningful title
#Highcharts JS theme 
hcYearPlot <- hcYearPlot + _____ + _____
hcYearPlot


#F. Now theme_gdocs()
#Google Docs Chart defaults with theme_gdocs
hcYearPlot <- hcYearPlot + _____
hcYearPlot


#G. Now  Few's "Practical rules for using color in charts", theme_few()
hcYearPlot <- hcYearPlot + _____
hcYearPlot


#H. Now fivethirtyeight.com
hcYearPlot <- hcYearPlot + _____
hcYearPlot


#E2. 
#A. Now group by DATA_YEAR, OFFENDER_RACE, summarize occurrences

hcYearOffenderRace <- hc %>% _____     %>%
  summarise(_____, .groups = "keep")


#B factorize race and get rid of NAs
str(hcYearOffenderRace$OFFENDER_RACE)

hcYearOffenderRace$OFFENDER_RACE <- as.factor(_____)

levels(hcYearOffenderRace$OFFENDER_RACE)

#we will remove the NAs
sum(hcYearOffenderRace$OFFENDER_RACE == "")

sum(hcYearOffenderRace$OFFENDER_RACE != "")

hcYearOffenderRace <- hcYearOffenderRace %>%
            filter(OFFENDER_RACE != "")

sum(hcYearOffenderRace$OFFENDER_RACE == "")


#B. Prepare basic line plot of occurrences vs year, colored by offender race


names(hcYearOffenderRace)

ggplot(hcYearOffenderRace) + geom_line(
          aes (_____  , _____, color = _______ )
          )


#C. Now make it nice using tools we introduced in the previous example


#_____________________________________


## Now we're interested in the relation between victim and offender counts


#E3. 
#A. Use hc to prep a jitterplot of victim counts vs offender counts

vcPLot <- ggplot(hc) + geom_jitter(aes(_____  , _____))
vcPlot


#B. use xlim(0,25) and ylim(0,25) to inspect a frament of the data

vcPlot  +  _____ + _____


#C. Make this prettier using what we have learned before, fixing point size 
#and alpha



names(hc)
#E4. 
#A. Do offender races have impact on offender group sizes? Draw a boxplot, 
#limit y t0 0,15

ggplot(_____) + geom_boxplot(aes( _____, 
                                  _____))+
                          coord_flip()+ _____

#B. How about offender races and victim group sizes? This time do a 
#scatterplot with jitter, same limit on  y


ggplot(hc) + _____(aes( _____, 
                        _____))+
  coord_flip()+_____


#C Make this look pretty 




