library(ggplot2)
library(ggthemes)
library(gridExtra)

setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


tit <- read.csv("titanic.csv",
                    header = TRUE)


str(tit)

titOrg <- ggplot(tit, aes(x = Survived, fill = Sex))+ 
  geom_bar()


titOrg

# ggplot(tit, aes(x = Survived, fill = Sex, y = (..count..)/sum(..count..))) + 
#   geom_bar()

 ggplot(tit, aes(x = Survived, fill = Sex, y = after_stat(count/sum(count)))) + 
  geom_bar()




#style

# ggplot(tit, aes(x = Survived, fill = Sex, y =  (..count..)/sum(..count..)))+ 
#   geom_bar()+theme_tufte()

ggplot(tit, aes(x = Survived, fill = Sex, y = after_stat(count/sum(count))))+ 
  geom_bar()+theme_tufte()


#continuous x?

str(tit)

tit$Survived <- factor(tit$Survived)

levels(tit$Survived)

levels(tit$Survived) <- c("perished", "survived")

str(tit$Survived)



# ggplot(tit, aes(x = Survived, fill = Sex, y = (..count..)/sum(..count..)))+ 
#   geom_bar() +theme_tufte()

ggplot(tit, aes(x = Survived, fill = Sex, y = after_stat(count/sum(count))))+ 
  geom_bar() +theme_tufte()

#width

# ggplot(tit, aes(x = Survived, fill = Sex, y = (..count..)/sum(..count..)))+ 
#   geom_bar(width = .8)+theme_tufte()

ggplot(tit, aes(x = Survived, fill = Sex, y = after_stat(count/sum(count))))+ 
  geom_bar(width = .8)+theme_tufte()

#base size

# ggplot(tit, aes(x = Survived, fill = Sex, y =(..count..)/sum(..count..)))+ 
#   geom_bar(width = .8)+theme_tufte(base_size = 20)


ggplot(tit, aes(x = Survived, fill = Sex, y = after_stat(count/sum(count))))+ 
  geom_bar(width = .8)+theme_tufte(base_size = 20)



# tPlot <- ggplot(tit, aes(x = Survived, fill = Sex, y = (..count..)/sum(..count..)))+ 
#   geom_bar(width = .8)+theme_tufte(base_size = 20)

tPlot <- ggplot(tit, aes(x = Survived, fill = Sex, y = after_stat(count/sum(count))))+ 
  geom_bar(width = .8)+theme_tufte(base_size = 20)


#flip

tPlot + coord_flip()


#remove y label

tPlot <- tPlot + coord_flip() + theme(axis.title.y=element_blank()) 

#percentage

tPlot <- tPlot + scale_y_continuous(labels = scales::percent)

tPlot


tPlot <- tPlot + theme(axis.title.x=element_blank()) 


tPlot

#annotations

tPlot +
  annotate(geom="text", x= 1, y = .3, label="male", color="black", size = 6)+
  annotate(geom="text", x= 2, y = .3, label="female", color="black", size = 6) +
  guides(fill = "none") 


#or move legend


tPlot <- tPlot + theme(legend.position = c(.8,.8))

tPlot
#title

tPlot <- tPlot +   ggtitle("Fate of Titanic passengers")

tPlot 

tPlot <- tPlot + theme(plot.title.position = "plot")


tPlot




tPlot


tPlot <- tPlot +  scale_fill_manual(values = c("antiquewhite3","azure4"))

grid.arrange(titOrg, tPlot, ncol = 1)



